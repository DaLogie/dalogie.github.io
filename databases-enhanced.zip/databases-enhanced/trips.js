const mongoose = require('mongoose');
const Trip = require('../models/travlr');

// GET: /trips - lists all trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();

    if (!trips || trips.length === 0) {
      return res
        .status(404)
        .json({ message: 'No trips found' });
    }

    return res
      .status(200)
      .json(trips);

  } catch (err) {
    return res
      .status(500)
      .json({
        message: 'Error retrieving trips',
        error: err.message
      });
  }
};

// GET: /trips/:tripCode - finds one trip by trip code
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip
      .findOne({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({ message: 'Trip not found' });
    }

    // Return as an array so the existing Angular edit-trip code still works
    return res
      .status(200)
      .json([trip]);

  } catch (err) {
    return res
      .status(500)
      .json({
        message: 'Error retrieving trip',
        error: err.message
      });
  }
};

// POST: /trips - adds a new trip
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = new Trip({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    const savedTrip = await newTrip.save();

    return res
      .status(201)
      .json(savedTrip);

  } catch (err) {
    return res
      .status(400)
      .json({
        message: 'Trip could not be saved',
        error: err.message
      });
  }
};

// PUT: /trips/:tripCode - updates an existing trip
const tripsUpdateTrip = async (req, res) => {
  try {
    const updatedTrip = await Trip
      .findOneAndUpdate(
        { code: req.params.tripCode },
        {
          code: req.body.code,
          name: req.body.name,
          length: req.body.length,
          start: req.body.start,
          resort: req.body.resort,
          perPerson: req.body.perPerson,
          image: req.body.image,
          description: req.body.description
        },
        {
          new: true,
          runValidators: true
        }
      )
      .exec();

    if (!updatedTrip) {
      return res
        .status(404)
        .json({ message: 'Trip not found or update failed' });
    }

    return res
      .status(200)
      .json(updatedTrip);

  } catch (err) {
    return res
      .status(400)
      .json({
        message: 'Trip update failed',
        error: err.message
      });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip
};