const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: [true, 'Trip code is required'],
      unique: true,
      index: true,
      trim: true
    },
    name: {
      type: String,
      required: [true, 'Trip name is required'],
      index: true,
      trim: true
    },
    length: {
      type: String,
      required: [true, 'Trip length is required'],
      trim: true
    },
    start: {
      type: Date,
      required: [true, 'Start date is required']
    },
    resort: {
      type: String,
      required: [true, 'Resort is required'],
      trim: true
    },
    perPerson: {
      type: Number,
      required: [true, 'Price per person is required'],
      min: [0, 'Price per person cannot be negative']
    },
    image: {
      type: String,
      required: [true, 'Image name is required'],
      trim: true
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true
    }
  },
  {
    timestamps: true
  }
);

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;