import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripCard } from '../trip-card/trip-card';
import { AuthenticationService } from '../services/authentication';

import { TripDataService } from '../services/trip-data';
import { Trip } from '../models/trip';

import { Router } from '@angular/router';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit {
  allTrips: Trip[] = [];
  trips: Trip[] = [];

  searchTerm: string = '';
  sortOption: string = 'default';

  message: string = '';
  errorMessage: string = '';
  isLoading: boolean = false;

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    console.log('trip-listing constructor');
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.loadTrips();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  public applyFilters(): void {
    let filteredTrips = [...this.allTrips];

    if (this.searchTerm.trim() !== '') {
      const searchValue = this.searchTerm.toLowerCase();

      filteredTrips = filteredTrips.filter((trip: Trip) =>
        trip.name.toLowerCase().includes(searchValue) ||
        trip.resort.toLowerCase().includes(searchValue) ||
        trip.code.toLowerCase().includes(searchValue)
      );
    }

    if (this.sortOption === 'priceLowHigh') {
      filteredTrips.sort((a: Trip, b: Trip) =>
        Number(a.perPerson) - Number(b.perPerson)
      );
    } else if (this.sortOption === 'priceHighLow') {
      filteredTrips.sort((a: Trip, b: Trip) =>
        Number(b.perPerson) - Number(a.perPerson)
      );
    } else if (this.sortOption === 'nameAZ') {
      filteredTrips.sort((a: Trip, b: Trip) =>
        a.name.localeCompare(b.name)
      );
    } else if (this.sortOption === 'nameZA') {
      filteredTrips.sort((a: Trip, b: Trip) =>
        b.name.localeCompare(a.name)
      );
    } else if (this.sortOption === 'dateSoonest') {
      filteredTrips.sort((a: Trip, b: Trip) =>
        new Date(a.start).getTime() - new Date(b.start).getTime()
      );
    } else if (this.sortOption === 'dateLatest') {
      filteredTrips.sort((a: Trip, b: Trip) =>
        new Date(b.start).getTime() - new Date(a.start).getTime()
      );
    }

    this.trips = filteredTrips;

    if (this.trips.length > 0) {
      this.message = 'Showing ' + this.trips.length + ' of ' + this.allTrips.length + ' trips.';
    } else {
      this.message = 'No trips match the current search or sort options.';
    }
  }

  public clearFilters(): void {
    this.searchTerm = '';
    this.sortOption = 'default';
    this.trips = [...this.allTrips];

    if (this.trips.length > 0) {
      this.message = 'There are ' + this.trips.length + ' trips available.';
    } else {
      this.message = 'There were no trips retrieved from the database.';
    }
  }

  private loadTrips(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.allTrips = value;
        this.trips = [...value];
        this.isLoading = false;

        if (value.length > 0) {
          this.message = 'There are ' + value.length + ' trips available.';
        } else {
          this.message = 'There were no trips retrieved from the database.';
        }

        console.log(this.message);
        console.log(this.trips);
      },
      error: (error: any) => {
        console.log('Error loading trips: ', error);
        this.isLoading = false;
        this.message = '';
        this.errorMessage = 'There was a problem loading trips from the database.';
      }
    });
  }
}
