import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

import { TripDataService } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  public editForm!: FormGroup;
  trip!: Trip;
  submitted = false;
  message: string = '';
  errorMessage: string = '';

  constructor(
    private formBuilder: FormBuilder,
    public router: Router,
    private route: ActivatedRoute,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');

    if (!tripCode) {
      this.message = 'No trip code was provided.';
      this.router.navigate(['']);
      return;
    }

    this.editForm = this.formBuilder.group({
      _id: [],
      code: [tripCode, Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });

    this.tripDataService.getTrip(tripCode).subscribe({
      next: (value: any) => {
        if (!value || value.length === 0) {
          this.message = 'No trip was retrieved.';
          return;
        }

        this.trip = value[0];

        this.editForm.patchValue({
          ...value[0],
          start: value[0].start ? value[0].start.split('T')[0] : ''
        });

        this.message = 'Trip: ' + tripCode + ' retrieved.';
        this.errorMessage = '';

        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error: ', error);
        this.errorMessage = 'There was a problem retrieving the trip.';
      }
    });
  }

  public onSubmit(): void {
    this.submitted = true;

    if (this.editForm.invalid) {
      this.errorMessage = 'Please complete all required fields before submitting.';
      return;
    }

    this.tripDataService.updateTrip(this.editForm.value).subscribe({
      next: (value: any) => {
        console.log(value);
        this.message = 'Trip was updated successfully.';
        this.errorMessage = '';
        this.router.navigate(['']);
      },
      error: (error: any) => {
        console.log('Error: ', error);
        this.errorMessage = 'There was a problem updating the trip.';
      }
    });
  }

  get f() {
    return this.editForm.controls;
  }
}
